package com.example.recipetracker

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.recipetracker.data.InMemoryRecipeRepository
import com.example.recipetracker.data.local.RecipeEntity
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class InMemoryRecipeViewModel(private val repo: InMemoryRecipeRepository) : ViewModel() {

    private val _showFavouritesOnly = MutableStateFlow(false)

    val recipes: StateFlow<List<RecipeEntity>> = combine(
        repo.recipes,
        _showFavouritesOnly
    ) { all, favOnly ->
        if (favOnly) all.filter { it.isFavourite } else all
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun toggleFavourite(recipe: RecipeEntity) = viewModelScope.launch {
        repo.save(recipe.copy(isFavourite = !recipe.isFavourite))
    }

    fun save(title: String) = viewModelScope.launch {
        repo.save(RecipeEntity(title = title))
    }

    fun setShowFavouritesOnly(enabled: Boolean) {
        _showFavouritesOnly.value = enabled
    }
}

