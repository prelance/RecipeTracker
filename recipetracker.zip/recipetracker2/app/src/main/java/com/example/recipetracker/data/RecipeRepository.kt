package com.example.recipetracker.data

import com.example.recipetracker.data.local.RecipeDao
import com.example.recipetracker.data.local.RecipeEntity
import kotlinx.coroutines.flow.Flow

class RecipeRepository(private val dao: RecipeDao) {
    fun getAll(): Flow<List<RecipeEntity>> = dao.getAllRecipes()
    suspend fun save(recipe: RecipeEntity) = dao.upsert(recipe)
    suspend fun delete(recipe: RecipeEntity) = dao.delete(recipe)
}
