package com.example.recipetracker.data

import com.example.recipetracker.data.local.RecipeEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class InMemoryRecipeRepository {
    private val _recipes = MutableStateFlow<List<RecipeEntity>>(emptyList())
    val recipes: StateFlow<List<RecipeEntity>> get() = _recipes

    suspend fun save(recipe: RecipeEntity) {
        val current = _recipes.value.toMutableList()
        val index = current.indexOfFirst { it.id == recipe.id && recipe.id != 0L }
        if (index >= 0) {
            current[index] = recipe
        } else {
            val nextId = (current.maxOfOrNull { it.id } ?: 0L) + 1
            current.add(recipe.copy(id = nextId))
        }
        _recipes.value = current
    }

    suspend fun delete(recipe: RecipeEntity) {
        _recipes.value = _recipes.value.filter { it.id != recipe.id }
    }
}

