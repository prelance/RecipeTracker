package com.example.recipetracker.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recipes")
data class RecipeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val isFavourite: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
