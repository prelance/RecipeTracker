package com.example.recipetracker

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.recipetracker.data.InMemoryRecipeRepository

class InMemoryRecipeViewModelFactory(private val repository: InMemoryRecipeRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(InMemoryRecipeViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return InMemoryRecipeViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
