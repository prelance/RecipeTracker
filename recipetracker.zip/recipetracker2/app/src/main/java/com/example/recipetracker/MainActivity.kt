package com.example.recipetracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import com.example.recipetracker.data.InMemoryRecipeRepository
import com.example.recipetracker.data.local.RecipeEntity

class MainActivity : ComponentActivity() {
    private lateinit var viewModel: InMemoryRecipeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val repo = InMemoryRecipeRepository()
        val factory = InMemoryRecipeViewModelFactory(repo)
        viewModel = ViewModelProvider(this, factory)[InMemoryRecipeViewModel::class.java]

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    RecipeApp(viewModel)
                }
            }
        }
    }
}

@Composable
fun RecipeApp(viewModel: InMemoryRecipeViewModel) {
    var currentScreen by remember { mutableStateOf("list") }
    val recipes by viewModel.recipes.collectAsState()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { currentScreen = "add" }) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add")
            }
        }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (currentScreen == "list") "My Recipes" else "Add Recipe",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.weight(1f)
                )
                if (currentScreen == "list") {
                    var showFavs by remember { mutableStateOf(false) }
                    IconButton(onClick = {
                        showFavs = !showFavs
                        viewModel.setShowFavouritesOnly(showFavs)
                    }) {
                        Icon(
                            imageVector = if (showFavs) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = "Filter favourites"
                        )
                    }
                }
            }

            if (currentScreen == "list") {
                RecipeListScreen(
                    recipeList = recipes,
                    onToggleFav = { viewModel.toggleFavourite(it) }
                )
            } else {
                AddRecipeScreen(onSave = {
                    viewModel.save(it)
                    currentScreen = "list"
                })
            }
        }
    }
}

@Composable
fun RecipeListScreen(
    recipeList: List<RecipeEntity>,
    onToggleFav: (RecipeEntity) -> Unit
) {
    if (recipeList.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("No recipes yet. Tap + to add one.")
        }
        return
    }

    LazyColumn {
        items(recipeList) { recipe ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = recipe.title, style = MaterialTheme.typography.titleMedium)
                        if (recipe.isFavourite) {
                            Text(text = "★ Favourite", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    IconButton(onClick = { onToggleFav(recipe) }) {
                        Icon(
                            imageVector = if (recipe.isFavourite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = "Favourite"
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AddRecipeScreen(onSave: (String) -> Unit) {
    var title by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        TextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Recipe Title") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (title.isNotBlank()) {
                    onSave(title)
                    title = ""
                }
            },
            modifier = Modifier.align(Alignment.End)
        ) {
            Text("Save")
        }
    }
}

